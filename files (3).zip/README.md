# Cricket Shot Recognition from Bat Sensors (Deep Learning)

Classify a batter's shot (defensive block, straight drive, cover drive, pull, square cut, sweep, lofted drive)
from a **bat-mounted IMU** (3-axis accelerometer + 3-axis gyroscope), using a **1D-CNN + BiLSTM + attention** network in PyTorch.

## Why it's different
- Time-series sensor data, not images; a real wearable-sports-analytics problem.
- **Player-wise splits**: test batters are never seen in training, so the score reflects generalisation to new people.
- **Physics-aware augmentation**: random sensor-frame rotation, time warping, time shift, scaling, jitter.
- **Interpretability**: attention weights show which moment of the swing the model uses.
- Compared against a Random Forest on hand-crafted features.

## Run
```bash
pip install -r requirements.txt
python data_generator.py   # synthetic data -> shots.npz  (skip if you have real data)
python baseline.py         # Random Forest baseline
python train.py            # train + evaluate + plots
python predict.py          # classify a sample shot
```
Real data: save an `.npz` with `X (N,128,6)`, `y (N,)`, `player (N,)` and run `python train.py --data yours.npz`.
Sensors can be an MPU-6050/9250 on the bat handle, or a phone strapped to it (resample to 100 Hz).

## Outputs (`outputs/`)
`shotnet.pt`, training curves, confusion matrix, attention-by-shot-type plot.

## Status
- Synthetic data: generated and verified. Random Forest baseline on unseen players: **acc 0.899, macro-F1 0.898**.
- `train.py` / `model.py` / `predict.py`: syntax-checked, but **not executed** where this was written (no PyTorch available). Run `train.py` and report your own numbers.

## Ideas to extend
- Real sensor data collected with a phone or IMU
- Add ball-speed / outcome (runs) as multi-task heads
- Transformer encoder vs. CNN-BiLSTM comparison
- Export to ONNX / TFLite for on-device use
