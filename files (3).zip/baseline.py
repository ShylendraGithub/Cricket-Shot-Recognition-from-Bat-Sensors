"""Classical baseline (hand-crafted features + Random Forest) with the same
player-wise split as the deep model, so the DL gain is measured honestly."""
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from data_generator import split_by_player


def features(X):
    f = []
    mag_a, mag_g = np.linalg.norm(X[:, :, :3], axis=2), np.linalg.norm(X[:, :, 3:], axis=2)
    T = X.shape[1]
    for c in range(X.shape[2]):
        v = X[:, :, c]
        f += [v.mean(1), v.std(1), v.min(1), v.max(1), np.ptp(v, 1),
              v.argmax(1) / T, v.argmin(1) / T, (v ** 2).sum(1)]
    for m in (mag_a, mag_g):
        f += [m.max(1), m.argmax(1) / T]
    return np.stack(f, 1)


if __name__ == "__main__":
    d = np.load("shots.npz")
    X, y, p = d["X"], d["y"], d["player"]
    tr, va, te = split_by_player(p)
    F = features(X)
    rf = RandomForestClassifier(400, random_state=0, n_jobs=-1).fit(F[np.r_[tr, va]], y[np.r_[tr, va]])
    pr = rf.predict(F[te])
    print(f"Random Forest baseline  acc={accuracy_score(y[te], pr):.3f}  macro-F1={f1_score(y[te], pr, average='macro'):.3f}")
