"""Synthetic bat-mounted IMU dataset for cricket shot classification.

Each sample = one shot, 1.28 s @ 100 Hz, 6 channels: [ax, ay, az, gx, gy, gz]
(accelerometer in g, gyroscope in rad/s-like units).

Realism features: per-player style (speed, power, timing, sensor bias, noise),
mistimed shots, sensor-orientation jitter. Splits are made BY PLAYER so the
model must generalise to batters it has never seen.

To use real data: save an .npz with X (N, 128, 6) float32, y (N,), player (N,)
and pass it to train.py with --data.
"""
import os
import numpy as np

CLASSES = ["Defensive block", "Straight drive", "Cover drive", "Pull shot",
           "Square cut", "Sweep", "Lofted drive"]
T, FS = 128, 100
CH = ["ax", "ay", "az", "gx", "gy", "gz"]

# gyro peak amplitudes (gx,gy,gz), impact timing offset, impact acc spike (ax,ay,az),
# resting gravity direction of the bat, swing width, follow-through strength
TEMPLATES = {
    0: dict(gyro=(0.5, -1.5, 0.3), t_off=0.00, imp=(0.5, 0.5, 3.0),  grav=(0.0, 0.0, 1.0),  width=0.06, follow=0.1),
    1: dict(gyro=(0.5, 6.0, 0.5),  t_off=0.00, imp=(1.0, 2.0, 10.0), grav=(0.1, 0.2, 0.95), width=0.07, follow=0.6),
    2: dict(gyro=(1.0, 5.0, 3.5),  t_off=0.01, imp=(3.0, 2.0, 9.0),  grav=(0.2, 0.1, 0.95), width=0.07, follow=0.7),
    3: dict(gyro=(2.5, -1.0, -6.5), t_off=-0.03, imp=(-4.0, 1.0, 8.0), grav=(0.5, 0.0, 0.8), width=0.06, follow=0.5),
    4: dict(gyro=(-3.0, 2.0, 5.0), t_off=0.05, imp=(5.0, -2.0, 7.0), grav=(0.4, -0.2, 0.85), width=0.05, follow=0.3),
    5: dict(gyro=(0.0, 4.0, -4.5), t_off=-0.05, imp=(-2.0, 3.0, 6.0), grav=(0.1, 0.6, 0.7), width=0.08, follow=0.8),
    6: dict(gyro=(1.0, 9.0, 1.5),  t_off=0.02, imp=(2.0, 3.0, 12.0), grav=(0.1, 0.1, 0.95), width=0.09, follow=1.0),
}


def _rot(rng, max_deg):
    ax = rng.normal(size=3); ax /= np.linalg.norm(ax)
    th = np.deg2rad(rng.uniform(-max_deg, max_deg))
    K = np.array([[0, -ax[2], ax[1]], [ax[2], 0, -ax[0]], [-ax[1], ax[0], 0]])
    return np.eye(3) + np.sin(th) * K + (1 - np.cos(th)) * K @ K


def _blend(a, b, lam):
    return {k: (np.array(a[k]) * (1 - lam) + np.array(b[k]) * lam) for k in a}


def _bump(t, c, w):
    return np.exp(-0.5 * ((t - c) / w) ** 2)


def make_sample(cls, player, rng):
    tp = TEMPLATES[cls]
    if rng.random() < 0.30:   # ambiguous hybrid shot: leans toward a neighbouring shot type
        other = rng.choice([c for c in TEMPLATES if c != cls])
        tp = _blend(tp, TEMPLATES[other], rng.uniform(0.1, 0.45))
    t = np.linspace(0, 1, T)
    mistimed = rng.random() < 0.20
    ti = 0.55 + tp["t_off"] + player["shift"] + rng.normal(0, 0.04)
    s = player["speed"] * rng.normal(1, 0.12)
    w = tp["width"] / s
    amp = player["amp"] * rng.normal(1, 0.25)

    gyro = np.zeros((T, 3))
    for k in range(3):
        a = tp["gyro"][k] * amp
        gyro[:, k] = (-0.35 * a * _bump(t, ti - 0.25 / s, 0.07)      # backlift
                      + a * _bump(t, ti - 0.04 / s, w)                # downswing
                      + 0.5 * tp["follow"] * a * _bump(t, ti + 0.15 / s, 0.12))  # follow-through

    grav = np.array(tp["grav"]) + rng.normal(0, 0.08, 3)
    acc = np.tile(grav, (T, 1)) + 0.12 * np.roll(gyro, 1, axis=1)
    after = t >= ti
    osc = np.where(after, np.exp(-(t - ti) / 0.02) * np.cos(2 * np.pi * 25 * (t - ti)), 0.0)
    imp_scale = 0.4 if mistimed else 1.0   # mistimed = weak, off-the-edge contact
    for k in range(3):
        acc[:, k] += tp["imp"][k] * amp * imp_scale * rng.normal(1, 0.3) * osc

    R = player["mount"] @ _rot(rng, 10)          # per-player mounting + per-shot wobble
    acc, gyro = acc @ R.T, gyro @ R.T
    x = np.concatenate([acc, gyro], axis=1)
    x += rng.normal(0, 1, x.shape) * player["noise"] * np.array([.25, .25, .25, .6, .6, .6])
    x += player["bias"]
    return x.astype(np.float32)


def generate(n_players=30, per_class=20, seed=7):
    rng = np.random.default_rng(seed)
    X, y, pid = [], [], []
    for p in range(n_players):
        player = dict(speed=rng.uniform(0.85, 1.2), amp=rng.uniform(0.7, 1.4),
                      shift=rng.normal(0, 0.03), noise=rng.uniform(0.6, 2.0), mount=_rot(rng, 20),
                      bias=rng.normal(0, 0.1, 6))
        for c in range(len(CLASSES)):
            for _ in range(per_class):
                X.append(make_sample(c, player, rng)); y.append(c); pid.append(p)
    return np.stack(X), np.array(y), np.array(pid)


def split_by_player(player, seed=0, val_frac=0.15, test_frac=0.2):
    """Return train/val/test index arrays with disjoint players."""
    players = np.unique(player)
    rng = np.random.default_rng(seed)
    rng.shuffle(players)
    n_test, n_val = max(1, round(len(players) * test_frac)), max(1, round(len(players) * val_frac))
    test_p, val_p = players[:n_test], players[n_test:n_test + n_val]
    idx = np.arange(len(player))
    return (idx[~np.isin(player, np.r_[test_p, val_p])],
            idx[np.isin(player, val_p)], idx[np.isin(player, test_p)])


def plot_samples(X, y, player, path):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    p0 = player[0]
    fig, ax = plt.subplots(len(CLASSES), 2, figsize=(11, 13), sharex=True)
    tt = np.arange(T) / FS
    for c in range(len(CLASSES)):
        i = np.where((y == c) & (player == p0))[0][0]
        for k in range(3):
            ax[c, 0].plot(tt, X[i, :, k], label=CH[k]); ax[c, 1].plot(tt, X[i, :, 3 + k], label=CH[3 + k])
        ax[c, 0].set_ylabel(CLASSES[c], rotation=0, ha="right", va="center")
    ax[0, 0].set_title("Accelerometer (g)"); ax[0, 1].set_title("Gyroscope")
    ax[0, 0].legend(ncol=3, fontsize=7); ax[0, 1].legend(ncol=3, fontsize=7)
    ax[-1, 0].set_xlabel("time (s)"); ax[-1, 1].set_xlabel("time (s)")
    plt.tight_layout(); plt.savefig(path, dpi=120); plt.close()


if __name__ == "__main__":
    os.makedirs("outputs/plots", exist_ok=True)
    X, y, pid = generate()
    np.savez_compressed("shots.npz", X=X, y=y, player=pid)
    plot_samples(X, y, pid, "outputs/plots/00_sample_signals.png")
    print(f"X {X.shape}, classes {np.bincount(y)}, players {len(np.unique(pid))} -> shots.npz")
