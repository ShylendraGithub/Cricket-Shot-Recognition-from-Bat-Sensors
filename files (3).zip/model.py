import torch
import torch.nn as nn


class ShotNet(nn.Module):
    """1D-CNN (local motion patterns) -> BiLSTM (temporal context) -> attention pooling.

    The attention weights show WHICH moment of the swing the network relied on
    (usually the downswing / ball impact), which makes the model interpretable.
    """

    def __init__(self, in_ch=6, n_classes=7, hidden=64, dropout=0.3):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(in_ch, 32, 7, padding=3), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 5, padding=2), nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(64, 128, 3, padding=1), nn.BatchNorm1d(128), nn.ReLU(), nn.MaxPool1d(2),
        )
        self.lstm = nn.LSTM(128, hidden, batch_first=True, bidirectional=True)
        self.attn = nn.Linear(2 * hidden, 1)
        self.head = nn.Sequential(
            nn.Dropout(dropout), nn.Linear(2 * hidden, 64), nn.ReLU(),
            nn.Dropout(dropout), nn.Linear(64, n_classes),
        )

    def forward(self, x, return_attn=False):          # x: (B, T, C)
        h = self.cnn(x.transpose(1, 2)).transpose(1, 2)   # (B, T/4, 128)
        h, _ = self.lstm(h)                                # (B, T/4, 2*hidden)
        w = torch.softmax(self.attn(h).squeeze(-1), dim=1) # (B, T/4)
        ctx = (h * w.unsqueeze(-1)).sum(dim=1)
        logits = self.head(ctx)
        return (logits, w) if return_attn else logits
