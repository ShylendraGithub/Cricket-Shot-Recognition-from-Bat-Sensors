"""Classify one shot.   python predict.py [shot.npy]   (array shape (T, 6): ax ay az gx gy gz)
With no file, a random synthetic shot is used as a demo."""
import sys

import numpy as np
import torch

from data_generator import CLASSES, TEMPLATES, make_sample
from model import ShotNet


def load(path="outputs/shotnet.pt"):
    ck = torch.load(path, map_location="cpu", weights_only=False)
    m = ShotNet(n_classes=len(ck["classes"])); m.load_state_dict(ck["state"]); m.eval()
    return m, ck


@torch.no_grad()
def predict(x, model, ck):
    x = np.asarray(x, dtype=np.float32)
    if len(x) != 128:  # resample to the training length
        x = np.stack([np.interp(np.linspace(0, len(x) - 1, 128), np.arange(len(x)), x[:, c]) for c in range(6)], 1)
    x = (x - ck["mean"]) / ck["std"]
    p = torch.softmax(model(torch.tensor(x)[None]), 1)[0].numpy()
    return sorted(zip(ck["classes"], p), key=lambda t: -t[1])


if __name__ == "__main__":
    model, ck = load()
    if len(sys.argv) > 1:
        x, truth = np.load(sys.argv[1]), "?"
    else:
        rng = np.random.default_rng()
        c = int(rng.integers(len(TEMPLATES)))
        player = dict(speed=1.0, amp=1.0, shift=0.0, noise=1.0, bias=np.zeros(6), mount=np.eye(3))
        x, truth = make_sample(c, player, rng), CLASSES[c]
    print("true shot:", truth)
    for name, p in predict(x, model, ck)[:3]:
        print(f"  {name:16s} {p:.1%}")
