"""Train CNN-BiLSTM-Attention on bat-sensor data with player-wise splits.

    python data_generator.py      # creates shots.npz (skip if you have real data)
    python train.py [--data shots.npz --epochs 60]
"""
import argparse
import copy
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from torch.utils.data import DataLoader, Dataset

from data_generator import CLASSES, FS, split_by_player
from model import ShotNet

OUT, PLOTS = "outputs", "outputs/plots"
sns.set_theme(style="whitegrid")


# ------------------------------- augmentation ------------------------------- #
def _rot(rng, max_deg=10):
    ax = rng.normal(size=3); ax /= np.linalg.norm(ax)
    th = np.deg2rad(rng.uniform(-max_deg, max_deg))
    K = np.array([[0, -ax[2], ax[1]], [ax[2], 0, -ax[0]], [-ax[1], ax[0], 0]])
    return np.eye(3) + np.sin(th) * K + (1 - np.cos(th)) * K @ K


def augment(x, rng):
    """x: (T, 6) raw signal. Sensor-frame rotation, time warp, shift, scaling."""
    R = _rot(rng)
    x = np.concatenate([x[:, :3] @ R.T, x[:, 3:] @ R.T], axis=1)
    T = len(x)
    speed = np.convolve(rng.normal(1, 0.2, T), np.ones(15) / 15, mode="same").clip(0.6, 1.5)
    warp = np.cumsum(speed); warp = (warp - warp[0]) / (warp[-1] - warp[0]) * (T - 1)
    x = np.stack([np.interp(np.arange(T), warp, x[:, c]) for c in range(x.shape[1])], axis=1)
    x = np.roll(x, rng.integers(-8, 9), axis=0)
    x[:, :3] *= rng.uniform(0.9, 1.1); x[:, 3:] *= rng.uniform(0.85, 1.15)
    return x


class ShotDataset(Dataset):
    def __init__(self, X, y, mean, std, train=False):
        self.X, self.y, self.mean, self.std, self.train = X, y, mean, std, train
        self.rng = np.random.default_rng(0)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, i):
        x = augment(self.X[i], self.rng) if self.train else self.X[i]
        x = (x - self.mean) / self.std
        x = x + self.rng.normal(0, 0.05, x.shape) if self.train else x  # jitter
        return torch.tensor(x, dtype=torch.float32), int(self.y[i])


# --------------------------------- training --------------------------------- #
@torch.no_grad()
def evaluate(model, loader, device, criterion=None):
    model.eval()
    preds, labels, attns, loss = [], [], [], 0.0
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        out, w = model(xb, return_attn=True)
        if criterion:
            loss += criterion(out, yb).item() * len(xb)
        preds.append(out.argmax(1).cpu()); labels.append(yb.cpu()); attns.append(w.cpu())
    p, l = torch.cat(preds).numpy(), torch.cat(labels).numpy()
    return loss / len(l), accuracy_score(l, p), f1_score(l, p, average="macro"), p, l, torch.cat(attns).numpy()


def main(a):
    os.makedirs(PLOTS, exist_ok=True)
    torch.manual_seed(0); np.random.seed(0)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    d = np.load(a.data)
    X, y, player = d["X"].astype(np.float32), d["y"], d["player"]
    tr, va, te = split_by_player(player)
    print(f"device={device} | train/val/test = {len(tr)}/{len(va)}/{len(te)} samples "
          f"(players {len(np.unique(player[tr]))}/{len(np.unique(player[va]))}/{len(np.unique(player[te]))}, disjoint)")

    mean, std = X[tr].mean((0, 1)), X[tr].std((0, 1)) + 1e-6
    mk = lambda idx, train: DataLoader(ShotDataset(X[idx], y[idx], mean, std, train),
                                       batch_size=64, shuffle=train)
    ltr, lva, lte = mk(tr, True), mk(va, False), mk(te, False)

    model = ShotNet(n_classes=len(CLASSES)).to(device)
    print(f"parameters: {sum(p.numel() for p in model.parameters()):,}")
    crit = nn.CrossEntropyLoss(label_smoothing=0.05)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-3)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="max", factor=0.5, patience=4)

    hist = {k: [] for k in ["train_loss", "val_loss", "val_acc", "val_f1"]}
    best_f1, best_state, bad = -1, None, 0
    for ep in range(1, a.epochs + 1):
        model.train(); tl = 0.0
        for xb, yb in ltr:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            loss = crit(model(xb), yb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); tl += loss.item() * len(xb)
        vl, vacc, vf1, *_ = evaluate(model, lva, device, crit)
        sched.step(vf1)
        for k, v in zip(hist, [tl / len(tr), vl, vacc, vf1]):
            hist[k].append(v)
        print(f"epoch {ep:3d} | train_loss {tl/len(tr):.3f} | val_loss {vl:.3f} | val_acc {vacc:.3f} | val_F1 {vf1:.3f}")
        if vf1 > best_f1:
            best_f1, best_state, bad = vf1, copy.deepcopy(model.state_dict()), 0
        else:
            bad += 1
            if bad >= a.patience:
                print("early stopping"); break

    model.load_state_dict(best_state)
    _, acc, f1, pred, true, attn = evaluate(model, lte, device)
    print(f"\nTEST (unseen players)  accuracy={acc:.3f}  macro-F1={f1:.3f}\n")
    print(classification_report(true, pred, target_names=CLASSES, digits=3))
    torch.save({"state": best_state, "mean": mean, "std": std, "classes": CLASSES}, f"{OUT}/shotnet.pt")

    # ------------------------------- plots ------------------------------- #
    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    ax[0].plot(hist["train_loss"], label="train"); ax[0].plot(hist["val_loss"], label="val")
    ax[0].set(title="Loss", xlabel="epoch"); ax[0].legend()
    ax[1].plot(hist["val_acc"], label="val accuracy"); ax[1].plot(hist["val_f1"], label="val macro-F1")
    ax[1].set(title="Validation metrics", xlabel="epoch"); ax[1].legend()
    plt.tight_layout(); plt.savefig(f"{PLOTS}/01_training_curves.png", dpi=130); plt.close()

    cm = confusion_matrix(true, pred, normalize="true")
    plt.figure(figsize=(8, 6.5))
    sns.heatmap(cm, annot=True, fmt=".2f", cmap="Blues", xticklabels=CLASSES, yticklabels=CLASSES)
    plt.title("Normalised confusion matrix (unseen players)"); plt.xticks(rotation=40, ha="right")
    plt.tight_layout(); plt.savefig(f"{PLOTS}/02_confusion_matrix.png", dpi=130); plt.close()

    # where in the swing does the network look? (attention over time, per class)
    tt = np.linspace(0, X.shape[1] / FS, attn.shape[1])
    plt.figure(figsize=(9, 4.5))
    for c, name in enumerate(CLASSES):
        m = true == c
        if m.any():
            plt.plot(tt, attn[m].mean(0), label=name)
    plt.xlabel("time (s)"); plt.ylabel("mean attention weight")
    plt.title("Temporal attention by shot type"); plt.legend(fontsize=8)
    plt.tight_layout(); plt.savefig(f"{PLOTS}/03_attention.png", dpi=130); plt.close()
    print(f"Saved model to {OUT}/shotnet.pt and plots to {PLOTS}/")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="shots.npz")
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--patience", type=int, default=10)
    main(ap.parse_args())
